# a07-exploring-the-cli-group-skeleton
A07 Exploring the CLI [Group]
